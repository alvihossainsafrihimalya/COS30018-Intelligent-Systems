# COS30018 - Intelligent Systems
# Task B.2 - Data Processing 1
# Name: Alvi Hossain Safri Himalya
# Student ID: 104223717

# Import necessary libraries for data processing, machine learning, and plotting

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM
from sklearn.model_selection import train_test_split


# ------------------------------------ FUNCTION TO LOAD AND PROCESS DATA -------------------------------------------
def process_stock_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'],
                       handle_nan=True, nan_method='drop', train_test_ratio=0.8, split_method='date',
                       save_to_disk=True, load_from_disk=False, apply_scaling=True):
    """
    The process_stock_data function is responsible for loading stock data, processing it, and handling
    potential issues such as NaN values. It also splits the data for training and testing purposes and
    offers options to save/load the processed data locally.

    Parameters:
    - ticker_symbol: str, the stock ticker (e.g., 'AAPL' for Apple Inc.).
    - start_date: str, start date in 'YYYY-MM-DD' format.
    - end_date: str, end date in 'YYYY-MM-DD' format.
    - features: list, the features/columns to be included in the dataset.
    - handle_nan: bool, whether to handle NaN values.
    - nan_method: str, method to handle NaN ('drop' to remove, 'fill' to forward-fill).
    - train_test_ratio: float, ratio to split data into training and testing sets.
    - split_method: str, method to split the data ('date' or 'random').
    - save_to_disk: bool, whether to save processed data locally.
    - load_from_disk: bool, whether to load data from local storage if available.
    - apply_scaling: bool, whether to scale the features between 0 and 1.

    Returns:
    - X_train, X_test, y_train, y_test: numpy arrays containing the processed data for training and testing.
    - scaler_dict: dict, containing the scalers for each feature.
    - data_path: str, the path where the data was saved or loaded from.
    """

    # Set up the directory and filename for saving/loading the dataset
    data_path = os.path.expanduser(f'~/Desktop/COS30018/Task_B2/{ticker_symbol}_{start_date}_{end_date}.csv')

    # Load data from local storage if the file exists and 'load_from_disk' is True
    if load_from_disk and os.path.exists(data_path):
        dataset = pd.read_csv(data_path, index_col='Date', parse_dates=True)
    else:
        # Download data from Yahoo Finance using yfinance library
        dataset = yf.download(ticker_symbol, start=start_date, end=end_date)
        # Save the downloaded data locally if 'save_to_disk' is True
        if save_to_disk:
            if not os.path.exists(os.path.dirname(data_path)):
                os.makedirs(os.path.dirname(data_path))
            dataset.to_csv(data_path)

    # Handle missing data according to the specified strategy
    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)

    # Select the specified features/columns from the dataset
    dataset = dataset[features]

    # Convert all data to float type to avoid any dtype issues during processing
    dataset = dataset.astype(float)

    # Initialize a dictionary to store scalers if scaling is applied
    scaler_dict = {}
    if apply_scaling:
        for feature in features:
            scaler = MinMaxScaler()
            dataset[feature] = scaler.fit_transform(dataset[feature].values.reshape(-1, 1))
            scaler_dict[feature] = scaler

    # Split the dataset into training and testing sets based on the chosen split method
    if split_method == 'date':
        train_size = int(len(dataset) * train_test_ratio)
        train_data = dataset.iloc[:train_size]
        test_data = dataset.iloc[train_size:]
    else:
        train_data, test_data = train_test_split(dataset, test_size=(1 - train_test_ratio), random_state=42)

    # Prepare the training and testing sequences for the LSTM model
    X_train, y_train = [], []
    X_test, y_test = [], []

    prediction_window = 60  # Number of days to look back for prediction

    # Create training sequences and corresponding target values
    for i in range(prediction_window, len(train_data)):
        X_train.append(train_data.iloc[i - prediction_window:i].values)
        y_train.append(train_data.iloc[i]['Close'])

    # Create testing sequences and corresponding target values
    for i in range(prediction_window, len(test_data)):
        X_test.append(test_data.iloc[i - prediction_window:i].values)
        y_test.append(test_data.iloc[i]['Close'])

    # Convert the lists to numpy arrays for use with TensorFlow/Keras
    return np.array(X_train), np.array(y_train), np.array(X_test), np.array(y_test), scaler_dict, data_path

# ------------------------------------------- MAIN SCRIPT STARTS HERE ----------------------------------------------

# Define the company ticker symbol and date range for data processing
ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'

# Process the data using the defined function
X_train, y_train, X_test, y_test, scalers, data_location = process_stock_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    split_method='date',
    save_to_disk=True,
    load_from_disk=False,
    apply_scaling=True
)

# Reshape the data to fit the LSTM model input requirements
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], len(['Open', 'High', 'Low', 'Close', 'Volume'])))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], len(['Open', 'High', 'Low', 'Close', 'Volume'])))

# ------------------------------------------- BUILD AND TRAIN THE MODEL --------------------------------------------

# Define the filename for saving/loading the trained model
model_file = f"{data_location.split('.')[0]}_model.h5"

# Check if a model already exists; if not, build and train a new model
if os.path.exists(model_file):
    model = tf.keras.models.load_model(model_file)
else:
    # Build an LSTM model with three layers and dropout to avoid overfitting
    model = Sequential()

    model.add(LSTM(units=50, return_sequences=True, input_shape=(X_train.shape[1], X_train.shape[2])))
    model.add(Dropout(0.2))

    model.add(LSTM(units=50, return_sequences=True))
    model.add(Dropout(0.2))

    model.add(LSTM(units=50))
    model.add(Dropout(0.2))

    model.add(Dense(units=1))  # Single output for predicting the 'Close' price

    # Compile the model using Adam optimizer and mean squared error as the loss function
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train the model on the training data
    model.fit(X_train, y_train, epochs=25, batch_size=32)

    # Save the trained model for future use
    model.save(model_file)

# ------------------------------------------- TEST THE MODEL PERFORMANCE --------------------------------------------

# Define the test period
test_start = '2023-08-02'
test_end = '2024-07-02'

# Download the test data to evaluate the model's accuracy
test_data = yf.download(ticker, start=test_start, end=test_end)
actual_prices = test_data['Close'].values

# Combine the training and test data for consistent scaling
total_dataset = pd.concat((pd.DataFrame(y_train, columns=['Close']), test_data[['Open', 'High', 'Low', 'Close', 'Volume']]), axis=0)

# Apply the saved scalers to the test data to maintain consistency
for feature in ['Open', 'High', 'Low', 'Close', 'Volume']:
    total_dataset[feature] = scalers[feature].transform(total_dataset[feature].values.reshape(-1, 1))

# Prepare sequences for testing the model's predictions
model_inputs = total_dataset[len(total_dataset) - len(test_data) - 60:].values

# Initialize an empty list to store test sequences
x_test = []
for i in range(60, len(model_inputs)):
    x_test.append(model_inputs[i - 60:i])

x_test = np.array(x_test)  # Convert list to numpy array

# Predict prices using the trained model and inverse transform to get original scale
predicted_prices = model.predict(x_test)
predicted_prices = scalers['Close'].inverse_transform(predicted_prices)

# ------------------------------------------- VISUALIZE THE RESULTS -------------------------------------------------

# Plot the actual vs predicted prices
plt.figure(figsize=(14, 7))
plt.plot(actual_prices, color="black", label=f"Actual {ticker} Price")
plt.plot(predicted_prices, color="blue", label=f"Predicted {ticker} Price")
plt.title(f"{ticker} Share Price Prediction")
plt.xlabel("Time")
plt.ylabel(f"{ticker} Share Price")
plt.legend()
plt.show()

# Plot candlestick chart for the test period to visualize stock movements
import mplfinance as mpf

# Use the test_data to create a candlestick chart
mpf.plot(test_data, type='candle', style='charles', title=f'{ticker} Candlestick Chart',
         ylabel='Price', volume=True)

# Plotting the high and low prices during the test period
plt.figure(figsize=(14, 7))
plt.plot(test_data['High'], color="green", label="High Price")
plt.plot(test_data['Low'], color="red", label="Low Price")
plt.title(f"{ticker} High and Low Prices")
plt.xlabel("Time")
plt.ylabel(f"{ticker} Price")
plt.legend()
plt.show()

# ------------------------------------------- FUTURE PRICE PREDICTION ------------------------------------------------

# Predict the next 5 days' prices using the trained model
days_to_predict = 5
future_predictions = []

for _ in range(days_to_predict):
    # Prepare the latest data sequence for prediction
    latest_data = model_inputs[-60:]  # Use the last 60 days from model_inputs
    latest_data = np.array([latest_data])

    # Predict the next day's closing price
    predicted_price = model.predict(latest_data)
    future_predictions.append(predicted_price[0, 0])

    # Update model_inputs to include the new prediction
    new_data = np.zeros((1, 60, 5))
    new_data[:, :, :-1] = model_inputs[-1, 1:]  # Shift the window by one day
    new_data[:, -1, -1] = predicted_price[0, 0]  # Add the predicted price

    model_inputs = np.append(model_inputs, new_data, axis=0)
    model_inputs = model_inputs[1:]  # Remove the oldest entry to maintain window size

# Convert future predictions back to the original scale
future_predictions = scalers['Close'].inverse_transform(np.array(future_predictions).reshape(-1, 1))

# Plot the predicted future prices alongside the actual prices
plt.figure(figsize=(14, 7))
plt.plot(range(len(actual_prices)), actual_prices, color="black", label="Actual Prices")
plt.plot(range(len(actual_prices), len(actual_prices) + days_to_predict), future_predictions, color="purple", label=f"Predicted Next {days_to_predict} Days")
plt.title(f"{ticker} Share Price Prediction for Next {days_to_predict} Days")
plt.xlabel("Time")
plt.ylabel(f"{ticker} Price")
plt.legend()
plt.show()

# Print the predictions for the next few days
print(f"Predicted prices for the next {days_to_predict} days:")
for i, price in enumerate(future_predictions, 1):
    print(f"Day {i}: {price[0]:.2f}")

