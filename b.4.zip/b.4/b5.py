import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
import os
import mplfinance as mpf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, SimpleRNN, Dropout, Dense, Bidirectional
from tensorflow.keras.callbacks import Callback

# Data processing function for multistep and multivariate prediction
def process_multistep_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'], 
                           handle_nan=True, nan_method='drop', train_test_ratio=0.8, split_method='date', 
                           save_to_disk=True, load_from_disk=False, apply_scaling=True, prediction_steps=5):
    data_path = f'{ticker_symbol}_{start_date}_{end_date}_multistep.csv'
    
    # Load or fetch data
    if load_from_disk and os.path.exists(data_path):
        dataset = pd.read_csv(data_path, index_col='Date', parse_dates=True)
    else:
        dataset = yf.download(ticker_symbol, start=start_date, end=end_date)
        if save_to_disk:
            dataset.to_csv(data_path)
    
    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)
    
    dataset = dataset[features].astype(float)
    
    # Scale the data
    scaler_dict = {}
    if apply_scaling:
        for feature in features:
            scaler = MinMaxScaler()
            dataset[feature] = scaler.fit_transform(dataset[feature].values.reshape(-1, 1))
            scaler_dict[feature] = scaler
    
    # Train/test split
    if split_method == 'date':
        train_size = int(len(dataset) * train_test_ratio)
        train_data = dataset.iloc[:train_size]
        test_data = dataset.iloc[train_size:]
    else:
        train_data, test_data = train_test_split(dataset, test_size=(1 - train_test_ratio), random_state=42)
    
    # Create multistep sequences
    X_train, y_train = [], []
    X_test, y_test = [], []
    prediction_window = 60  # Look-back window

    for i in range(prediction_window, len(train_data) - prediction_steps + 1):
        X_train.append(train_data.iloc[i - prediction_window:i].values)
        y_train.append(train_data.iloc[i:i + prediction_steps]['Close'].values)  # Predict future k steps
    
    for i in range(prediction_window, len(test_data) - prediction_steps + 1):
        X_test.append(test_data.iloc[i - prediction_window:i].values)
        y_test.append(test_data.iloc[i:i + prediction_steps]['Close'].values)
    
    return np.array(X_train), np.array(y_train), np.array(X_test), np.array(y_test), scaler_dict, data_path

# Keras Callback to plot training and validation loss dynamically
class TrainingPlotCallback(Callback):
    def on_epoch_end(self, epoch, logs=None):
        if epoch == 0:
            self.losses = {'loss': [], 'val_loss': []}
        self.losses['loss'].append(logs['loss'])
        self.losses['val_loss'].append(logs['val_loss'])

        plt.figure(figsize=(10, 6))
        plt.plot(self.losses['loss'], label='Training Loss')
        plt.plot(self.losses['val_loss'], label='Validation Loss')
        plt.title(f"Epoch {epoch + 1} Loss")
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.legend()
        plt.grid(True)
        plt.show()

# Function to dynamically create a deep learning model for multistep prediction
def create_multistep_model(layer_type, num_layers, layer_size, input_shape, dropout_rate=0.2, bidirectional=False, prediction_steps=5):
    model = Sequential()
    
    # Add the first layer with input shape
    if bidirectional:
        if layer_type == 'LSTM':
            model.add(Bidirectional(LSTM(layer_size, return_sequences=True, input_shape=input_shape)))
        elif layer_type == 'GRU':
            model.add(Bidirectional(GRU(layer_size, return_sequences=True, input_shape=input_shape)))
        elif layer_type == 'RNN':
            model.add(Bidirectional(SimpleRNN(layer_size, return_sequences=True, input_shape=input_shape)))
    else:
        if layer_type == 'LSTM':
            model.add(LSTM(layer_size, return_sequences=True, input_shape=input_shape))
        elif layer_type == 'GRU':
            model.add(GRU(layer_size, return_sequences=True, input_shape=input_shape))
        elif layer_type == 'RNN':
            model.add(SimpleRNN(layer_size, return_sequences=True, input_shape=input_shape))
    
    # Add the remaining layers
    for _ in range(1, num_layers):
        if layer_type == 'LSTM':
            model.add(LSTM(layer_size, return_sequences=True))
        elif layer_type == 'GRU':
            model.add(GRU(layer_size, return_sequences=True))
        elif layer_type == 'RNN':
            model.add(SimpleRNN(layer_size, return_sequences=True))
        model.add(Dropout(dropout_rate))
    
    # Output layer for multistep prediction
    model.add(Dense(prediction_steps))  # Predict k future steps
    
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Training function to experiment with different models and configurations for multistep prediction
def train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='LSTM', num_layers=2, layer_size=50, 
                             epochs=50, batch_size=32, bidirectional=False, prediction_steps=5):
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = create_multistep_model(model_type, num_layers, layer_size, input_shape, bidirectional=bidirectional, prediction_steps=prediction_steps)
    
 
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), 
                        verbose=1, callbacks=[TrainingPlotCallback()])
    
   
    test_loss = model.evaluate(X_test, y_test)
    print(f"{model_type} Model with {num_layers} layers and {layer_size} units per layer - Test Loss: {test_loss}")
    
    return history, model


ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'

# Process the data (with multistep, multivariate prediction)
X_train, y_train, X_test, y_test, scalers, data_location = process_multistep_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    split_method='date',
    save_to_disk=True,
    load_from_disk=False,
    apply_scaling=True,
    prediction_steps=5  # Predict 5 days into the future
)

# Experiment with different configurations for multistep, multivariate prediction
configurations = [
    {'model_type': 'LSTM', 'num_layers': 2, 'layer_size': 50, 'epochs': 10, 'batch_size': 32, 'bidirectional': True},
    {'model_type': 'GRU', 'num_layers': 3, 'layer_size': 100, 'epochs': 15, 'batch_size': 64, 'bidirectional': False},
]

# Loop through the configurations and evaluate each model
results = []
for config in configurations:
    print(f"Training {config['model_type']} model with {config['num_layers']} layers, {config['layer_size']} units, {config['epochs']} epochs, and batch size {config['batch_size']}...")
    
    # Train and evaluate the model
    history, model = train_and_evaluate_model(
        X_train, y_train, X_test, y_test,
        model_type=config['model_type'],
        num_layers=config['num_layers'],
        layer_size=config['layer_size'],
        epochs=config['epochs'],
        batch_size=config['batch_size'],
        bidirectional=config['bidirectional'],
        prediction_steps=5
    )
    
    # Record the test loss for this configuration
    test_loss = model.evaluate(X_test, y_test, verbose=0)
    results.append({
        'model_type': config['model_type'],
        'num_layers': config['num_layers'],
        'layer_size': config['layer_size'],
        'epochs': config['epochs'],
        'batch_size': config['batch_size'],
        'bidirectional': config['bidirectional'],
        'test_loss': test_loss
    })

# Print out the summary of results
print("\nSummary of Results:")
for result in results:
    print(f"Model: {result['model_type']}, Layers: {result['num_layers']}, Units: {result['layer_size']}, Epochs: {result['epochs']}, Batch Size: {result['batch_size']}, Bidirectional: {result['bidirectional']}, Test Loss: {result['test_loss']}")
