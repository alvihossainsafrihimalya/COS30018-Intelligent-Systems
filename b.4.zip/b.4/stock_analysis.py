import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
import mplfinance as mpf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, SimpleRNN, Dropout, Dense, Bidirectional
from tensorflow.keras.callbacks import Callback

# Data processing function (from Task B.3)
def process_stock_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'], 
                       handle_nan=True, nan_method='drop', train_test_ratio=0.8, split_method='date', 
                       save_to_disk=True, load_from_disk=False, apply_scaling=True):
    data_path = f'{ticker_symbol}_{start_date}_{end_date}.csv'
    
    if load_from_disk and os.path.exists(data_path):
        dataset = pd.read_csv(data_path, index_col='Date', parse_dates=True)
    else:
        dataset = yf.download(ticker_symbol, start=start_date, end=end_date)
        if save_to_disk:
            dataset.to_csv(data_path)
    
    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)
    
    dataset = dataset[features].astype(float)
    
    scaler_dict = {}
    if apply_scaling:
        for feature in features:
            scaler = MinMaxScaler()
            dataset[feature] = scaler.fit_transform(dataset[feature].values.reshape(-1, 1))
            scaler_dict[feature] = scaler
    
    if split_method == 'date':
        train_size = int(len(dataset) * train_test_ratio)
        train_data = dataset.iloc[:train_size]
        test_data = dataset.iloc[train_size:]
    else:
        train_data, test_data = train_test_split(dataset, test_size=(1 - train_test_ratio), random_state=42)
    
    X_train, y_train = [], []
    X_test, y_test = [], []
    prediction_window = 60
    
    for i in range(prediction_window, len(train_data)):
        X_train.append(train_data.iloc[i - prediction_window:i].values)
        y_train.append(train_data.iloc[i]['Close'])
    
    for i in range(prediction_window, len(test_data)):
        X_test.append(test_data.iloc[i - prediction_window:i].values)
        y_test.append(test_data.iloc[i]['Close'])
    
    return np.array(X_train), np.array(y_train), np.array(X_test), np.array(y_test), scaler_dict, data_path

# Keras Callback to plot training and validation loss dynamically
class TrainingPlotCallback(Callback):
    def on_epoch_end(self, epoch, logs=None):
        if epoch == 0:
            self.losses = {'loss': [], 'val_loss': []}
        self.losses['loss'].append(logs['loss'])
        self.losses['val_loss'].append(logs['val_loss'])

        plt.figure(figsize=(10, 6))
        plt.plot(self.losses['loss'], label='Training Loss')
        plt.plot(self.losses['val_loss'], label='Validation Loss')
        plt.title(f"Epoch {epoch + 1} Loss")
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.legend()
        plt.grid(True)
        plt.show()

# Function to dynamically create a deep learning model (for Task B.4)
def create_dl_model(layer_type, num_layers, layer_size, input_shape, dropout_rate=0.2, bidirectional=False):
    model = Sequential()
    
    # Add the first layer with input shape
    if bidirectional:
        if layer_type == 'LSTM':
            model.add(Bidirectional(LSTM(layer_size, return_sequences=True, input_shape=input_shape)))
        elif layer_type == 'GRU':
            model.add(Bidirectional(GRU(layer_size, return_sequences=True, input_shape=input_shape)))
        elif layer_type == 'RNN':
            model.add(Bidirectional(SimpleRNN(layer_size, return_sequences=True, input_shape=input_shape)))
    else:
        if layer_type == 'LSTM':
            model.add(LSTM(layer_size, return_sequences=True, input_shape=input_shape))
        elif layer_type == 'GRU':
            model.add(GRU(layer_size, return_sequences=True, input_shape=input_shape))
        elif layer_type == 'RNN':
            model.add(SimpleRNN(layer_size, return_sequences=True, input_shape=input_shape))
    
    # Add the remaining layers
    for _ in range(1, num_layers):
        if layer_type == 'LSTM':
            model.add(LSTM(layer_size, return_sequences=True))
        elif layer_type == 'GRU':
            model.add(GRU(layer_size, return_sequences=True))
        elif layer_type == 'RNN':
            model.add(SimpleRNN(layer_size, return_sequences=True))
        model.add(Dropout(dropout_rate))
    
    # Output layer
    model.add(Dense(1))
    
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Training function to experiment with different models and configurations
def train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='LSTM', num_layers=2, layer_size=50, 
                             epochs=50, batch_size=32, bidirectional=False):
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = create_dl_model(model_type, num_layers, layer_size, input_shape, bidirectional=bidirectional)
    
    # Train the model with dynamic loss plotting
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), 
                        verbose=1, callbacks=[TrainingPlotCallback()])
    
    # Evaluate the model
    test_loss = model.evaluate(X_test, y_test)
    print(f"{model_type} Model with {num_layers} layers and {layer_size} units per layer - Test Loss: {test_loss}")
    
    return history, model

# Visualization functions (from Task B.3)
def plot_candlestick_chart(data, ticker_symbol, aggregate_days=1, include_ma=False):
    if aggregate_days > 1:
        data = data.resample(f'{aggregate_days}D').agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        }).dropna()
    
    if include_ma:
        data['MA50'] = data['Close'].rolling(window=50).mean()
        data['MA100'] = data['Close'].rolling(window=100).mean()
        data['MA200'] = data['Close'].rolling(window=200).mean()
        addplots = [mpf.make_addplot(data['MA50']),
                    mpf.make_addplot(data['MA100']),
                    mpf.make_addplot(data['MA200'])]
    else:
        addplots = []

    mpf.plot(data, type='candle', style='charles', title=f'{ticker_symbol} Candlestick Chart',
             ylabel='Price', volume=True, addplot=addplots)

def plot_boxplot_chart(data, ticker_symbol, window_size=5, k=10):
    boxplot_data = []
    for i in range(len(data) - window_size + 1):
        window_data = data['Close'].iloc[i:i + window_size].values
        boxplot_data.append(window_data)
    
    plt.figure(figsize=(10, 6))
    plt.boxplot(boxplot_data, patch_artist=True)
    plt.title(f'{ticker_symbol} Boxplot Chart (Window Size: {window_size} days)')
    plt.xlabel('Time Windows')
    plt.ylabel('Price')

    labels = data.index[::k]
    plt.xticks(ticks=range(1, len(labels) + 1), labels=labels, rotation=45)
    
    plt.show()

# Example usage for Task B.4
ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'

# Process the data (from Task B.3)
X_train, y_train, X_test, y_test, scalers, data_location = process_stock_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    split_method='date',
    save_to_disk=True,
    load_from_disk=False,
    apply_scaling=True
)

# Experiment with different deep learning models (Task B.4)
lstm_history, lstm_model = train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='LSTM', 
                                                    num_layers=2, layer_size=50, epochs=10, batch_size=32, bidirectional=True)
gru_history, gru_model = train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='GRU', 
                                                  num_layers=2, layer_size=50, epochs=10, batch_size=32, bidirectional=False)
rnn_history, rnn_model = train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='RNN', 
                                                  num_layers=2, layer_size=50, epochs=10, batch_size=32, bidirectional=False)

# Load the data again for visualization
data = yf.download(ticker, start=train_start, end=train_end)

# Plot the candlestick chart with moving averages
plot_candlestick_chart(data, ticker, aggregate_days=1, include_ma=True)

# Plot the boxplot chart with custom window size and label spacing
plot_boxplot_chart(data, ticker, window_size=10, k=10)
