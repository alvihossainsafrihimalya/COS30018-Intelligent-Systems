import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dropout, Dense

# Function to process stock data
def process_stock_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'], 
                       handle_nan=True, nan_method='drop', train_test_ratio=0.8, prediction_window=60):
    dataset = yf.download(ticker_symbol, start=start_date, end=end_date)

    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)

    dataset = dataset[features].astype(float)

    scaler = MinMaxScaler()
    dataset_scaled = scaler.fit_transform(dataset)

    X, y = [], []
    for i in range(prediction_window, len(dataset_scaled)):
        X.append(dataset_scaled[i - prediction_window:i])
        y.append(dataset_scaled[i, 3])  # 3 corresponds to 'Close' in the features (1-dimensional output)

    X, y = np.array(X), np.array(y)

    y = y.reshape(-1, 1)  # Ensure y is of shape (samples, 1)

    # Train/test split
    train_size = int(len(X) * train_test_ratio)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]

    return X_train, y_train, X_test, y_test, scaler, dataset

# Function to create an LSTM model
def create_lstm_model(input_shape, num_layers=2, layer_size=50, dropout_rate=0.2, future_steps=1):
    model = Sequential()
    for i in range(num_layers):
        if i == 0:
            model.add(LSTM(layer_size, return_sequences=True, input_shape=input_shape))
        else:
            model.add(LSTM(layer_size, return_sequences=True))
        model.add(Dropout(dropout_rate))

    model.add(LSTM(layer_size, return_sequences=False))  # Final LSTM layer
    model.add(Dense(future_steps))  # Output layer for multistep prediction
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Multistep prediction function
def multistep_prediction(X_data, model, k):
    predictions = []
    current_input = X_data[-1]  # Start with the last data point from test set

    for _ in range(k):
        current_input_reshaped = current_input.reshape(1, *current_input.shape)  # Reshape to match the input shape
        predicted_price = model.predict(current_input_reshaped)[0][0]  # Get the predicted price

        predictions.append(predicted_price)

        # Prepare new input: Replace the last feature (close price) with the predicted price
        new_input = np.append(current_input[1:], [[predicted_price] * current_input.shape[1]], axis=0)

        current_input = new_input  # Update current input with the new sequence

    return predictions

# Plot actual vs predicted prices
def plot_actual_vs_predicted(y_test, predictions, title="Actual vs Predicted Stock Prices"):
    plt.figure(figsize=(10, 6))
    plt.plot(y_test.flatten(), label="Actual Prices")
    plt.plot(predictions, label="Predicted Prices", linestyle="--")
    plt.title(title)
    plt.xlabel("Days")
    plt.ylabel("Stock Price")
    plt.legend()
    plt.grid(True)
    plt.show()

# Training and evaluation function for LSTM model
def train_and_evaluate_model(X_train, y_train, X_test, y_test, future_steps=5, epochs=10, batch_size=32):
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = create_lstm_model(input_shape, future_steps=future_steps)

    # Train the model
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test), verbose=1)

    # Evaluate the model
    test_loss = model.evaluate(X_test, y_test)
    print(f"LSTM Model - Test Loss: {test_loss}")
    
    return model

# Process the data for multivariate and multistep prediction
ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'
future_steps = 5  # Predict the next 5 days

X_train, y_train, X_test, y_test, scaler, dataset = process_stock_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    prediction_window=60
)

# Modify y to accommodate multistep prediction
y_train_multistep = np.array([y_train[i:i + future_steps] for i in range(len(y_train) - future_steps)])
y_test_multistep = np.array([y_test[i:i + future_steps] for i in range(len(y_test) - future_steps)])

y_train_multistep = y_train_multistep.reshape(-1, future_steps)
y_test_multistep = y_test_multistep.reshape(-1, future_steps)

X_train = X_train[:len(y_train_multistep)]
X_test = X_test[:len(y_test_multistep)]

# Train and evaluate the LSTM model
model = train_and_evaluate_model(X_train, y_train_multistep, X_test, y_test_multistep, future_steps=future_steps)

# Make predictions for the next 5 days
predictions = multistep_prediction(X_test, model, future_steps)

# Plot the actual vs predicted stock prices
plot_actual_vs_predicted(y_test_multistep[:, 0], predictions)
