import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
import mplfinance as mpf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dropout, Dense

# Your B.2 data processing function
def process_stock_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'], 
                       handle_nan=True, nan_method='drop', train_test_ratio=0.8, split_method='date', 
                       save_to_disk=True, load_from_disk=False, apply_scaling=True):
    data_path = f'{ticker_symbol}_{start_date}_{end_date}.csv'
    
    if load_from_disk and os.path.exists(data_path):
        dataset = pd.read_csv(data_path, index_col='Date', parse_dates=True)
    else:
        dataset = yf.download(ticker_symbol, start=start_date, end=end_date)
        if save_to_disk:
            dataset.to_csv(data_path)
    
    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)
    
    dataset = dataset[features].astype(float)
    
    scaler_dict = {}
    if apply_scaling:
        for feature in features:
            scaler = MinMaxScaler()
            dataset[feature] = scaler.fit_transform(dataset[feature].values.reshape(-1, 1))
            scaler_dict[feature] = scaler
    
    if split_method == 'date':
        train_size = int(len(dataset) * train_test_ratio)
        train_data = dataset.iloc[:train_size]
        test_data = dataset.iloc[train_size:]
    else:
        train_data, test_data = train_test_split(dataset, test_size=(1 - train_test_ratio), random_state=42)
    
    X_train, y_train = [], []
    X_test, y_test = [], []
    prediction_window = 60
    
    for i in range(prediction_window, len(train_data)):
        X_train.append(train_data.iloc[i - prediction_window:i].values)
        y_train.append(train_data.iloc[i]['Close'])
    
    for i in range(prediction_window, len(test_data)):
        X_test.append(test_data.iloc[i - prediction_window:i].values)
        y_test.append(test_data.iloc[i]['Close'])
    
    return np.array(X_train), np.array(y_train), np.array(X_test), np.array(y_test), scaler_dict, data_path

# B.3 visualization functions
def plot_candlestick_chart(data, ticker_symbol, aggregate_days=1, include_ma=False):
    if aggregate_days > 1:
        data = data.resample(f'{aggregate_days}D').agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        }).dropna()
    
    if include_ma:
        data['MA50'] = data['Close'].rolling(window=50).mean()
        data['MA100'] = data['Close'].rolling(window=100).mean()
        data['MA200'] = data['Close'].rolling(window=200).mean()
        addplots = [mpf.make_addplot(data['MA50']),
                    mpf.make_addplot(data['MA100']),
                    mpf.make_addplot(data['MA200'])]
    else:
        addplots = []

    mpf.plot(data, type='candle', style='charles', title=f'{ticker_symbol} Candlestick Chart',
             ylabel='Price', volume=True, addplot=addplots)

def plot_boxplot_chart(data, ticker_symbol, window_size=5, k=10):
    boxplot_data = []
    for i in range(len(data) - window_size + 1):
        window_data = data['Close'].iloc[i:i + window_size].values
        boxplot_data.append(window_data)
    
    plt.figure(figsize=(10, 6))
    plt.boxplot(boxplot_data, patch_artist=True)
    plt.title(f'{ticker_symbol} Boxplot Chart (Window Size: {window_size} days)')
    plt.xlabel('Time Windows')
    plt.ylabel('Price')

    labels = data.index[::k]
    plt.xticks(ticks=range(1, len(labels) + 1), labels=labels, rotation=45)
    
    plt.show()

# Example usage of your functions
ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'

# Process the data
X_train, y_train, X_test, y_test, scalers, data_location = process_stock_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    split_method='date',
    save_to_disk=True,
    load_from_disk=False,
    apply_scaling=True
)

# Load the data again for visualization
data = yf.download(ticker, start=train_start, end=train_end)

# Plot the candlestick chart with moving averages
plot_candlestick_chart(data, ticker, aggregate_days=1, include_ma=True)

# Plot the boxplot chart with custom window size and label spacing
plot_boxplot_chart(data, ticker, window_size=10, k=10)
