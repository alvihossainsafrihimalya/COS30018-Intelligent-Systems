import numpy as np
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dropout, Dense, Bidirectional
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.statespace.sarimax import SARIMAX
import mplfinance as mpf
import matplotlib.pyplot as plt

# Function to fetch external data (e.g., sentiment scores)
def fetch_external_data(ticker_symbol, start_date, end_date):
    date_range = pd.date_range(start=start_date, end=end_date)
    sentiment_scores = np.random.uniform(-1, 1, len(date_range))  # Dummy sentiment scores (-1 to 1)
    
    return pd.DataFrame({'Date': date_range, 'SentimentScore': sentiment_scores})

# Modified data processing function to include external data
def process_stock_data_with_external(ticker_symbol, start_date, end_date, 
                                     features=['Open', 'High', 'Low', 'Close', 'Volume'],
                                     handle_nan=True, nan_method='drop', 
                                     train_test_ratio=0.8, prediction_window=60):
    stock_data = yf.download(ticker_symbol, start=start_date, end=end_date)
    stock_data.reset_index(inplace=True)  # Resetting index so 'Date' is a regular column
    external_data = fetch_external_data(ticker_symbol, start_date, end_date)
    merged_data = pd.merge(stock_data, external_data, how='inner', on='Date')

    if handle_nan:
        if nan_method == 'drop':
            merged_data.dropna(inplace=True)
        elif nan_method == 'fill':
            merged_data.fillna(method='ffill', inplace=True)

    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(merged_data[features + ['SentimentScore']])
    
    X, y = [], []
    for i in range(prediction_window, len(scaled_data)):
        X.append(scaled_data[i - prediction_window:i])
        y.append(scaled_data[i, 3])  # Assuming 'Close' is the 4th column (index 3)
    
    X, y = np.array(X), np.array(y)
    
    train_size = int(len(X) * train_test_ratio)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]
    
    return X_train, y_train, X_test, y_test, scaler, merged_data

# ARIMA model function
def arima_model(train_data, order=(5, 1, 0)):
    model = ARIMA(train_data, order=order)
    model_fit = model.fit()
    return model_fit

# SARIMA model function
def sarima_model(train_data, order=(5, 1, 0), seasonal_order=(1, 1, 1, 12)):
    model = SARIMAX(train_data, order=order, seasonal_order=seasonal_order)
    model_fit = model.fit(disp=False)
    return model_fit

# Random Forest model function
def random_forest_model(X_train, y_train):
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
    rf_model.fit(X_train.reshape(X_train.shape[0], -1), y_train)
    return rf_model

# Ensemble prediction function with ARIMA and SARIMA
def ensemble_prediction_rf_arima_sarima(X_test, dl_model, arima_fit, sarima_fit, rf_model, future_steps):
    # Limit LSTM predictions to match ARIMA, SARIMA, and Random Forest for the next 'future_steps' only
    dl_predictions = dl_model.predict(X_test)[:future_steps]
    rf_predictions = rf_model.predict(X_test.reshape(X_test.shape[0], -1))[:future_steps]
    arima_predictions = arima_fit.forecast(steps=future_steps)
    sarima_predictions = sarima_fit.forecast(steps=future_steps)
    
    # Simple averaging for ensemble
    ensemble_predictions = (dl_predictions[:, 0] + arima_predictions + sarima_predictions + rf_predictions) / 4
    return ensemble_predictions, dl_predictions[:, 0], arima_predictions, sarima_predictions, rf_predictions

# Visualization: Candlestick chart function
def plot_candlestick_chart(data):
    data.index = pd.to_datetime(data['Date'])
    mpf.plot(data.set_index('Date'), type='candle', volume=True, title='Candlestick Chart', ylabel='Price')

# Visualization: Boxplot function
def plot_boxplot(data):
    data.boxplot(column=['Open', 'High', 'Low', 'Close'], grid=False)
    plt.title("Boxplot of Stock Data")
    plt.show()

# Enhanced Visualization: Actual vs Predicted Prices
def plot_actual_vs_predicted(y_test, ensemble_preds, dl_preds, arima_preds, sarima_preds, rf_preds, future_steps):
    plt.figure(figsize=(10, 6))
    plt.plot(y_test[:future_steps], label="Actual Prices", color="blue", marker="o")
    plt.plot(ensemble_preds, label="Ensemble Predictions", linestyle="--", color="green")
    plt.plot(dl_preds, label="LSTM Predictions", linestyle="--", color="red")
    plt.plot(arima_preds, label="ARIMA Predictions", linestyle="--", color="orange")
    plt.plot(sarima_preds, label="SARIMA Predictions", linestyle="--", color="purple")
    plt.plot(rf_preds, label="RF Predictions", linestyle="--", color="brown")
    plt.title("Actual vs Predicted Prices (Next {} Days)".format(future_steps))
    plt.xlabel("Days")
    plt.ylabel("Price")
    plt.legend()
    plt.grid(True)
    plt.show()

# Enhanced Visualization: Prediction Errors (Residuals)
def plot_residuals(y_test, ensemble_preds, future_steps):
    residuals = y_test[:future_steps] - ensemble_preds
    plt.figure(figsize=(10, 6))
    plt.plot(residuals, label="Prediction Residuals", marker="o", linestyle="--", color="red")
    plt.title("Prediction Residuals (Error) for Next {} Days".format(future_steps))
    plt.xlabel("Days")
    plt.ylabel("Error")
    plt.legend()
    plt.grid(True)
    plt.show()

# Main function to integrate everything
def integrate_arima_sarima_and_rf():
    ticker = 'AAPL'
    train_start = '2010-01-01'
    train_end = '2020-12-31'
    
    X_train, y_train, X_test, y_test, scaler, merged_data = process_stock_data_with_external(
        ticker_symbol=ticker,
        start_date=train_start,
        end_date=train_end,
        features=['Open', 'High', 'Low', 'Close', 'Volume'],
        handle_nan=True,
        nan_method='drop',
        train_test_ratio=0.8,
        prediction_window=60
    )
    
    dl_model = Sequential([
        Bidirectional(LSTM(100, return_sequences=True), input_shape=(X_train.shape[1], X_train.shape[2])),
        Dropout(0.2),
        LSTM(100),
        Dropout(0.2),
        Dense(1)
    ])
    dl_model.compile(optimizer='adam', loss='mean_squared_error')
    dl_model.fit(X_train, y_train, epochs=10, batch_size=64, validation_data=(X_test, y_test), verbose=1)
    
    arima_fit = arima_model(y_train, order=(5, 1, 0))
    sarima_fit = sarima_model(y_train, order=(5, 1, 0), seasonal_order=(1, 1, 1, 12))
    
    rf_model = random_forest_model(X_train, y_train)
    
    future_steps = 5
    ensemble_preds, dl_preds, arima_preds, sarima_preds, rf_preds = ensemble_prediction_rf_arima_sarima(X_test, dl_model, arima_fit, sarima_fit, rf_model, future_steps)
    
    # Plot actual vs predicted prices with multiple models
    plot_actual_vs_predicted(y_test, ensemble_preds, dl_preds, arima_preds, sarima_preds, rf_preds, future_steps)
    
    # Plot prediction residuals
    plot_residuals(y_test, ensemble_preds, future_steps)
    
    # Candlestick chart
    plot_candlestick_chart(merged_data)
    
    # Boxplot
    plot_boxplot(merged_data)

# Call the integration function
integrate_arima_sarima_and_rf()
