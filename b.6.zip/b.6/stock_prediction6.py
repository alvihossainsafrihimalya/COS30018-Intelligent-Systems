import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dropout, Dense, Bidirectional
from tensorflow.keras.callbacks import Callback
from statsmodels.tsa.arima.model import ARIMA
import mplfinance as mpf


# Function to process stock data
def process_stock_data(ticker_symbol, start_date, end_date, features=['Open', 'High', 'Low', 'Close', 'Volume'],
                       handle_nan=True, nan_method='drop', train_test_ratio=0.8, prediction_window=60):
    dataset = yf.download(ticker_symbol, start=start_date, end=end_date)

    if handle_nan:
        if nan_method == 'drop':
            dataset.dropna(inplace=True)
        elif nan_method == 'fill':
            dataset.fillna(method='ffill', inplace=True)

    dataset = dataset[features].astype(float)

    scaler = MinMaxScaler()
    dataset_scaled = scaler.fit_transform(dataset)

    X, y = [], []
    for i in range(prediction_window, len(dataset_scaled)):
        X.append(dataset_scaled[i - prediction_window:i])
        y.append(dataset_scaled[i, 3])  # 3 corresponds to 'Close' in the features (1-dimensional output)

    X, y = np.array(X), np.array(y)

    # Reshape y to ensure it matches the expected shape (batch_size, 1)
    y = y.reshape(-1, 1)  #  y is of shape (samples, 1)

    # Train/test split
    train_size = int(len(X) * train_test_ratio)
    X_train, X_test = X[:train_size], X[train_size:]
    y_train, y_test = y[:train_size], y[train_size:]

    return X_train, y_train, X_test, y_test, scaler, dataset


# Candlestick chart function
def plot_candlestick_chart(data):
    # Convert to DataFrame with datetime index for mplfinance
    data.index = pd.to_datetime(data.index)
    mpf.plot(data, type='candle', volume=True, title='Candlestick Chart', ylabel='Price', ylabel_lower='Volume')


# Boxplot chart function
def plot_boxplot(data, feature='Close'):
    plt.boxplot(data[feature], vert=True)
    plt.title(f"Boxplot of {feature}")
    plt.ylabel(f"{feature}")
    plt.grid(True)
    plt.show()


# Callback class for live plot
class TrainingPlotCallback(Callback):
    def on_epoch_end(self, epoch, logs=None):
        if epoch == 0:
            self.losses = {'loss': [], 'val_loss': []}
        self.losses['loss'].append(logs['loss'])
        self.losses['val_loss'].append(logs['val_loss'])
        plt.figure(figsize=(10, 6))
        plt.plot(self.losses['loss'], label='Training Loss')
        plt.plot(self.losses['val_loss'], label='Validation Loss')
        plt.title(f"Epoch {epoch + 1} Loss")
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.legend()
        plt.grid(True)
        plt.show()


# Function to create a deep learning model
def create_dl_model(layer_type, num_layers, layer_size, input_shape, dropout_rate=0.2, bidirectional=False, future_steps=1):
    model = Sequential()
    for i in range(num_layers):
        if i == 0:
            if bidirectional:
                if layer_type == 'LSTM':
                    model.add(Bidirectional(LSTM(layer_size, return_sequences=True, input_shape=input_shape)))
                elif layer_type == 'GRU':
                    model.add(Bidirectional(GRU(layer_size, return_sequences=True, input_shape=input_shape)))
            else:
                if layer_type == 'LSTM':
                    model.add(LSTM(layer_size, return_sequences=True, input_shape=input_shape))
                elif layer_type == 'GRU':
                    model.add(GRU(layer_size, return_sequences=True, input_shape=input_shape))
        else:
            # For all intermediate layers, return_sequences=True
            if layer_type == 'LSTM':
                model.add(LSTM(layer_size, return_sequences=True))
            elif layer_type == 'GRU':
                model.add(GRU(layer_size, return_sequences=True))
        model.add(Dropout(dropout_rate))

    # Final layer should not return sequences, we just want the final output
    if layer_type == 'LSTM':
        model.add(LSTM(layer_size, return_sequences=False))
    elif layer_type == 'GRU':
        model.add(GRU(layer_size, return_sequences=False))

    model.add(Dense(future_steps))  # Output layer for multistep prediction
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model


# ARIMA model
def arima_model(y_train, order=(5, 1, 0)):
    model = ARIMA(y_train, order=order)
    arima_fit = model.fit()
    return arima_fit


# Function to combine ARIMA and DL models
def ensemble_prediction(X_data, dl_model, arima_fit, future_steps=5):
    dl_predictions = multistep_prediction(X_data, dl_model, future_steps)

    # ARIMA predictions
    arima_predictions = arima_fit.forecast(steps=future_steps)

    # Ensemble: simple averaging of ARIMA and DL predictions
    ensemble_predictions = (np.array(dl_predictions) + np.array(arima_predictions)) / 2
    return ensemble_predictions, dl_predictions, arima_predictions


# Training and evaluation function for DL model
def train_and_evaluate_model(X_train, y_train, X_test, y_test, model_type='LSTM', num_layers=2, layer_size=50, 
                             epochs=10, batch_size=32, bidirectional=False, future_steps=1):
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = create_dl_model(model_type, num_layers, layer_size, input_shape, bidirectional=bidirectional, future_steps=future_steps)
    
    # Train the model with dynamic loss plotting
    history = model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_data=(X_test, y_test),
                        verbose=1, callbacks=[TrainingPlotCallback()])

    # Evaluate the model
    test_loss = model.evaluate(X_test, y_test)
    print(f"{model_type} Model - Test Loss: {test_loss}")
    return history, model


# Multistep prediction function for DL model
def multistep_prediction(X_data, model, k):
    predictions = []
    current_input = X_data[-1]  # Start with the last data point from test set

    for _ in range(k):
        current_input_reshaped = current_input.reshape(1, *current_input.shape)  # Reshape to match the input shape
        predicted_price = model.predict(current_input_reshaped)[0][0]  # Get the predicted price

        predictions.append(predicted_price)

        # Prepare new input: Replace the last feature (close price) with the predicted price
        new_input = np.append(current_input[1:], [[predicted_price] * current_input.shape[1]], axis=0)

        current_input = new_input  # Update current input with the new sequence

    return predictions


# Process the data for multivariate and multistep
ticker = 'CBA.AX'
train_start = '2020-01-01'
train_end = '2023-08-01'
future_steps = 5  # Number of future steps to predict

X_train, y_train, X_test, y_test, scaler, dataset = process_stock_data(
    ticker_symbol=ticker,
    start_date=train_start,
    end_date=train_end,
    features=['Open', 'High', 'Low', 'Close', 'Volume'],
    handle_nan=True,
    nan_method='drop',
    train_test_ratio=0.8,
    prediction_window=60
)

# Modify y to accommodate multistep prediction (y_train/y_test will have multiple steps)
y_train_multistep = np.array([y_train[i:i + future_steps] for i in range(len(y_train) - future_steps)])
y_test_multistep = np.array([y_test[i:i + future_steps] for i in range(len(y_test) - future_steps)])

# Ensure y_train_multistep and y_test_multistep have the correct shape
y_train_multistep = y_train_multistep.reshape(-1, future_steps)
y_test_multistep = y_test_multistep.reshape(-1, future_steps)

X_train = X_train[:len(y_train_multistep)]  # Match dimensions
X_test = X_test[:len(y_test_multistep)]  # Match dimensions

# Train and evaluate the DL model
history, dl_model = train_and_evaluate_model(X_train, y_train_multistep, X_test, y_test_multistep, model_type='LSTM', 
                                             num_layers=2, layer_size=50, epochs=10, batch_size=32, 
                                             bidirectional=False, future_steps=future_steps)

# ARIMA model training on the training set
arima_fit = arima_model(y_train[:, 0], order=(5, 1, 0))

# Ensemble predictions
ensemble_preds, dl_preds, arima_preds = ensemble_prediction(X_test, dl_model, arima_fit, future_steps)

# Display predictions
print(f"Ensemble Predictions for the next {future_steps} days: {ensemble_preds}")
print(f"DL Model Predictions: {dl_preds}")
print(f"ARIMA Model Predictions: {arima_preds}")


# xtra visualization: Compare actual prices vs predicted prices
def plot_actual_vs_predicted(y_test, ensemble_preds):
    plt.figure(figsize=(10, 6))
    plt.plot(y_test.flatten(), label="Actual Prices")
    plt.plot(ensemble_preds, label="Predicted Prices", linestyle="--")
    plt.title("Actual vs Predicted Prices")
    plt.xlabel("Days")
    plt.ylabel("Price")
    plt.legend()
    plt.grid(True)
    plt.show()


#  actual vs predicted prices
plot_actual_vs_predicted(y_test_multistep, ensemble_preds)

# andlestick chart
plot_candlestick_chart(dataset)

# boxplot
plot_boxplot(dataset)
